

var video = document.getElementById("example");
var videoSource = document.getElementById("vid-src");
var descriptionSource = document.getElementById("despsrc");


function hamburger()
{
    var menu = document.getElementById("menu-links");
    var log = document.getElementById("ffc-logo");
    if(menu.style.display ==="block" && log.style.display === "none")
    {
        menu.style.display = "none";
        log.style.display = "block";

    }
    else
    {
        menu.style.display = "block";
        log.style.display = "none";
    }
}

function burpees()
{
    videoSource.src = "media/burpees.mp4";
    descriptionSource.src = "media/burpees-descriptions.vtt";
    video.style.display = "block";
    video.load();


}