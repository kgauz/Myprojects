#include "item.h"

Item::Item() {
    name ="";
}

Item::Item(QString nameP)
{
    name = nameP;
}
