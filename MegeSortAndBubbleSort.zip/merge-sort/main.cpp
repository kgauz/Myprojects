

#include <iostream>
#include <vector>
#include "ctime"
using namespace std;

double comparisoncountM =0;  // global variable for merge sort
//Function for the first sorting algorithm
void bubbleSort(vector<int>&r, int &comparisons)
{
    comparisons =0;
    for(int i = 1; i < r.size(); i++)
    {
        for(int j =0; j < r.size() - i; j++)
        {
            comparisons++;
            if(r[j] > r[j +1])
            {
                int temp = r[j];
                r[j] = r[j + 1];
                r[j + 1] = temp;
            }
        }
    }
}



//Function for the second sorting algorithm
void merge(vector<int> & array, int const left, int const middle, int const right) {
    int const array1 = middle - left + 1;
    int const array2 = right - middle;

    // Create temp arrays
    auto *leftArray = new int[array1];
    auto *rightArray = new int[array2];

    // Copy data to temp arrays leftArray[] and rightArray[]
    for (auto i = 0; i < array1; i++)
        leftArray[i] = array[left + i];
    for (auto j = 0; j < array2; j++)
        rightArray[j] = array[middle+ 1 + j];

    int count1 = 0, count2 = 0;
    int countOfMergeArray = left;

    // Merge the temp arrays back into array[left..right]
    while (count1 < array1 && count2 < array2) {
        comparisoncountM++;
        if (leftArray[count1] <= rightArray[count2]) {
            array[countOfMergeArray] = leftArray[count1];
            count1++;
        } else {
            array[countOfMergeArray] = rightArray[count2];
            count2++;
        }
        countOfMergeArray++;
    }

    // Copy the remaining elements of left[], if there are any
    while (count1 < array1) {
        array[countOfMergeArray] = leftArray[count1];
        count1++;
        countOfMergeArray++;
    }

    // Copy the remaining elements of right[], if there are any
    while (count2 < array2) {
        array[countOfMergeArray] = rightArray[count2];
        count2++;
        countOfMergeArray++;
    }

    delete[] leftArray;
    delete[] rightArray;
}
void mergeSort(vector<int>&arr, int const startOfElements, int const lastElement)
{
    if (startOfElements >= lastElement)
        return;

    int middle = startOfElements + (lastElement - startOfElements) / 2;
    mergeSort(arr, startOfElements, middle);
    mergeSort(arr, middle + 1, lastElement);
    merge(arr, startOfElements, middle, lastElement);

}



//Function to generate a random array of a given size
vector<int> generateRandomArray(int size) {

    vector<int> arr(size);
    srand(time(0));
    for (int i = 0; i < size; ++i) {
        arr[i] = rand() % 1000; //adjust the range to play around with it
    }

    return arr;

} //generateRandomArray


//you can make this more code efficient - did it this way for more clarity purposes

void measureSortingTimeFirstSortingAlgorithm(vector<int>& arr, double& timeExecuted, double& timeComplexity) {

    //measure start time
    clock_t startTime = clock();
    int comparisons =0;

    //Call your first sorting algorithm
    bubbleSort(arr, comparisons);


    //measure end time

    clock_t endTime = clock();


    //calculate executation time in secods for first sorting algorithm

    timeExecuted = (static_cast<double>((endTime - startTime))) / (static_cast<double>(CLOCKS_PER_SEC));;

    //calculate time comlexity for your sorting algorithm

    timeComplexity = comparisons; //this will then be the time complexity - you must provide the code

} //measureSortingTimeFirstSortingAlgorithm



void measureSortingTimeSecondSortingAlgorithm(vector<int>& arr , double  &timeExecuted, double &timeComplexity   ) {

    //measure start time
    clock_t startTime = clock();
    //Call your second algortihm
    mergeSort(arr, 0, arr.size() -1);


    //measure end time

    clock_t endTime = clock();

    //calculate executation time in secods for first sorting algorithm

    timeExecuted = (static_cast<double>((endTime - startTime))) / (static_cast<double>(CLOCKS_PER_SEC));;


    //calculate time comlexity for your sorting algorithm

    timeComplexity = comparisoncountM; //this will then be the time complexity - you must provide the code

} //measureSortingTimeSecondSortingAlgorithm




int main()
{

    //generate an array with 100 random elements

    double timeExecuted1, timeExecuted2;
    double timeComplexity1, timeComplexity2;


    vector<int> inputSizes = { 100,1000,5000};

    for (int size : inputSizes) {
        vector<int> arr = generateRandomArray(size);

        //measure the sorting time for sorting algorithm

        measureSortingTimeFirstSortingAlgorithm(arr,timeExecuted1,timeComplexity1);

        measureSortingTimeSecondSortingAlgorithm(arr,timeExecuted2,timeComplexity2);

        //The display of your results will go here.

        cout<<endl;
        cout.setf(ios::fixed);
        cout.precision(4);

        cout<<"Input Size: "<<size<<endl;
        cout<<endl;
        cout << "Bubble Sort: "<<endl;
        cout << "Executed in Time:  " << timeExecuted1 << " seconds." << endl;
        cout<<endl;
        cout<<endl;
        cout << "Merge Sort:"<<endl;
        cout << "Executed Time:  " << timeExecuted2 << " seconds." <<endl;
        cout<<endl;
    }
    cout<<"The time complexity formular for bubble sort: "<<" O(n ^2)"<<endl;
    cout<<"The time complexity formular for Merge sort: "<<" O(nlogn)"<<endl;
    cout<<endl;

    //the above may not be the best way to code it - it is just to give you a headstart.



    return 0;
} //main
